from .erin_quick_scripts import QuickScripts

Krita.instance().addExtension(QuickScripts(Krita.instance()))
